<?php if (isset($component)) { $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e = $attributes; } ?>
<?php $component = App\View\Components\DefaultLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<style>
    th {
        font-weight: 700;
    }
    h1 {
        font-size: 18px;
        font-weight: bold;
        text-align: left;
        margin-top: 0;
    }
    table {
        border-collapse: collapse;
        width: 100%;
        padding: 1px;
    }
    th, td {
        padding: 1px;
        text-align: left;
    }
    th {
        background-color: rgba(17, 153, 5, 0.774);
    }
    .logo {
        position: relative;
        margin-top: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 50px;
    }
    .img {
        width: 120px;
        height: 120px;
    }
    .img2 {
        width: 180px;
        height: 130px;
    }
    .qrcode img {
        height: 150px;
        width: 150px;
    }
</style>

<h1>TCC Records</h1>

<table id="tccss" class="table table-striped border rounded gy-5 gs-7">
    <thead>
        <tr>
            <th>Name</th>
            <th>GTIN</th>
            <th>Tax paid 2023 (NGN)</th>
            <th>Tax Outstanding 2023 (NGN)</th>
            <th>Business Status</th>
            <th>Ref Number</th>
            <th>Approval Status</th>
            <th>Rejection Status</th>
            <th>View TCC</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $tccs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tcc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($tcc->name); ?></td>
            <td><?php echo e($tcc->gtin); ?></td>
            <td><?php echo e($tcc->taxpaidyr3); ?></td>
            <td><?php echo e($tcc->tccType); ?></td>
            <td><?php echo e($tcc->business_status); ?></td>
            <td><?php echo e($tcc->ref_no); ?></td>
            <!--<td>-->
            <!--    <?php if($tcc->status !== 'approved'): ?>-->
            <!--    <form action="<?php echo e(route('tcc.approve', $tcc->id)); ?>" method="POST">-->
            <!--        <?php echo csrf_field(); ?>-->
            <!--        <button type="submit" class="btn btn-success">Approve</button>-->
            <!--    </form>-->
            <!--    <?php else: ?>-->
            <!--    Approved-->
            <!--    <?php endif; ?>-->
            <!--</td>-->
            <td>
            <?php if($tcc->status === 'approved'): ?>
                Approved
            <?php elseif($tcc->status !== 'rejected'): ?>
                <form action="<?php echo e(route('tcc.approve', $tcc->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success">Approve</button>
                </form>
            <?php else: ?>
                <!-- Status is "rejected" so nothing is displayed -->
            <?php endif; ?>
        </td>
            <td>
                <?php if($tcc->status !== 'approved' && $tcc->status !== 'rejected'): ?>
                <button type="button" class="btn btn-danger reject-btn" data-tcc-id="<?php echo e($tcc->id); ?>" data-bs-toggle="modal" data-bs-target="#rejectModal">Reject</button>
                <?php elseif($tcc->status === 'rejected'): ?>
                Rejected
                <?php endif; ?>
            </td>
            <td>
                <button type="button" class="btn btn-primary view-tcc-btn" data-tcc="<?php echo e(json_encode($tcc)); ?>" data-bs-toggle="modal" data-bs-target="#tccModal">
                    View TCC
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<!-- Modal structure -->
<div class="modal fade" id="tccModal" tabindex="-1" aria-labelledby="tccModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tccModalLabel">Tax Clearance Certificate</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="tccContent">
                   
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rejectModalLabel">Reason for Rejection</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="rejectForm" action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="reason" class="form-label">Please provide a reason for the rejection:</label>
                        <textarea class="form-control" id="reason" name="reason" rows="3" required></textarea>
                    </div>
                    <input type="hidden" name="tcc_id" id="tcc_id" value="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject</button>
                </div>
            </form>
        </div>
    </div>
</div>



<script>
   $(document).on('click', '.reject-btn', function () {
        var tccId = $(this).data('tcc-id');
        $('#rejectForm').attr('action', '/tcc/reject/' + tccId);
        $('#tcc_id').val(tccId);
    });



    $(document).on('click', '.view-tcc-btn', function () {
        var tcc = $(this).data('tcc');
        var modalBody = `
            <h1 style="text-align:center">Gombe State Internal Revenue Service</h1>
            <h4 style="text-align:center">ADDRESS: Opposite Custodian Hotel...</h4>
            <h3 style="text-align: center; font-weight: bold; background-color: rgb(17, 153, 5); color: #fff; padding: 5px;">GOMBE STATE TAX CLEARANCE CERTIFICATE</h3>
            <table>
                <tr><td><b>TCC No:</b></td><td>: ${tcc.id}</td></tr>
                <tr><td><b>Date Of Issue:</b></td><td>: ${new Date().toLocaleDateString()}</td></tr>
                <tr><td><b>Expiry Date:</b></td><td>: 31-12-2024</td></tr>
                <tr><td><b>Name Of Taxpayer:</b></td><td>: ${tcc.name}</td></tr>
                <tr><td><b>BN No:</b></td><td>: ${tcc.rc || ''}</td></tr>
                <tr><td><b>Date Of Incorporation:</b></td><td>: ${tcc.date_of_incorporation || ''}</td></tr>
                <tr><td><b>GTIN:</b></td><td>: ${tcc.gtin}</td></tr>
                <tr><td><b>TIN:</b></td><td>: ${tcc.tin || ''}</td></tr>
                <tr><td><b>Business Address:</b></td><td>: ${tcc.business_address || ''}</td></tr>
                <tr><td><b>Business Status:</b></td><td>: ${tcc.business_status || ''}</td></tr>
                <tr><td><b>Tax Paid (2021):</b></td><td>: NGN ${tcc.taxpaidyr1}</td></tr>
                <tr><td><b>Tax Paid (2022):</b></td><td>: NGN ${tcc.taxpaidyr2}</td></tr>
                <tr><td><b>Tax Paid (2023):</b></td><td>: NGN ${tcc.taxpaidyr3}</td></tr>
            </table>
          
        `;
        $('#tccContent').html(modalBody);
    });

    $(document).ready(function () {
        $('#tccss').DataTable();
    });
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $attributes = $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $component = $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php /**PATH /home/gombeirs/public_html/resources/views/tcc/TCCapprover.blade.php ENDPATH**/ ?>