<?php if (isset($component)) { $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e = $attributes; } ?>
<?php $component = App\View\Components\DefaultLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<style>
    th{
        font-weight: 700;
    }
</style>

    <h1>TCC Records</h1>
    
  <table id="tccss" class="table table-striped border rounded gy-5 gs-7">
    <thead>
        <tr>
            <th>Name</th>
            <th>GTIN</th>
            <th>Tax paid 2023 (NGN)</th>
            <th>Tax Outstanding 2023 (NGN)</th>
            <th>Business Status</th>
            <th>Ref Number</th>
            <th>Download</th>
            <th>Comment</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $tccs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tcc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($tcc->name); ?></td>
                <td><?php echo e($tcc->gtin); ?></td>
                <td><?php echo e($tcc->taxpaidyr3); ?></td>
                <td><?php echo e($tcc->taxOutstandingyr3); ?></td>
                <td><?php echo e($tcc->business_status); ?></td>
                <td><?php echo e($tcc->ref_no); ?></td>
                <td>
                  <?php if($tcc->status === 'approved'): ?>
                        <div class="dropdown">
                            <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton<?php echo e($tcc->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                Download
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?php echo e($tcc->id); ?>">
                                <li><a class="dropdown-item downloadIndividual" href="#" data-tcc-id="<?php echo e($tcc->id); ?>">Download Individual</a></li>
                                <li><a class="dropdown-item downloadBtn" href="#" data-tcc-id="<?php echo e($tcc->id); ?>">Download All</a></li>
                            </ul>
                        </div>
                    <?php elseif($tcc->status === 'rejected'): ?>
                        <h6 style="color: red;">TCC Rejected</h6>
                    <?php else: ?>
                        TCC not Approved
                    <?php endif; ?>
                </td>
                <td><?php echo e($tcc->comment); ?></td>
                <td>
                    <?php if($tcc->status === 'rejected'): ?>
                        <a href="<?php echo e(route('tcc.edit', $tcc->id)); ?>" class="btn btn-primary btn-sm editTcc" data-tcc-id="<?php echo e($tcc->id); ?>">
                            Edit
                        </a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>




 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>


<script>
    $('#tccss').DataTable();
    
$(document).on('click', '.downloadBtn', function() {
    var tccId = $(this).data('tcc-id');
    console.log("Button clicked with tccId:", tccId);
    downloadPdf(tccId);
});

function downloadPdf(tccId) {
    var url = '<?php echo e(route("downloadPdf", ":tccId")); ?>';
    url = url.replace(':tccId', tccId);
    console.log("Download URL:", url);
    window.location = url;
}
$(document).on('click', '.downloadIndividual', function() {
    var tccId = $(this).data('tcc-id');
    console.log("Button clicked with tccId:", tccId);
    downloadPdf2(tccId);
});

function downloadPdf2(tccId) {
    var url = '<?php echo e(route("downloadPdf2", ":tccId")); ?>';
    url = url.replace(':tccId', tccId);
    console.log("Download URL:", url);
    window.location = url;
}

$(document).ready(function() {
    $('.editTcc').click(function() {
        var id = $(this).data('tcc-id');
        var url = '<?php echo e(route("tcc.edit", ":id")); ?>';
        url = url.replace(':id', id);
    });
});




</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $attributes = $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $component = $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php /**PATH /home/gombeirs/public_html/resources/views/tcc/showTCC.blade.php ENDPATH**/ ?>