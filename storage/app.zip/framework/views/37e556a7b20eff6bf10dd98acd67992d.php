<!--begin::Scrolltop-->
<div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true"><?php echo getIcon('arrow-up', ''); ?></div>
<!--end::Scrolltop--><?php /**PATH /home/gombeirs/public_html/resources/views/partials/_scrolltop.blade.php ENDPATH**/ ?>