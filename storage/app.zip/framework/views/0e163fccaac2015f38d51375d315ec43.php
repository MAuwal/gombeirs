<!--begin::Activities drawer-->
<div id="kt_activities" class="bg-body" data-kt-drawer="true" data-kt-drawer-name="activities" data-kt-drawer-activate="true" data-kt-drawer-overlay="true" data-kt-drawer-width="{default:'300px', 'lg': '900px'}" data-kt-drawer-direction="end" data-kt-drawer-toggle="#kt_activities_toggle" data-kt-drawer-close="#kt_activities_close">
	<div class="card shadow-none border-0 rounded-0">
		<!--begin::Header-->
		<div class="card-header" id="kt_activities_header">
			<h3 class="card-title fw-bold text-dark">Activity Logs</h3>
			<div class="card-toolbar">
				<button type="button" class="btn btn-sm btn-icon btn-active-light-primary me-n5" id="kt_activities_close"><?php echo getIcon('cross', 'fs-1'); ?></button>
			</div>
		</div>
		<!--end::Header-->
		<!--begin::Body-->
		<div class="card-body position-relative" id="kt_activities_body">
			<!--begin::Content-->
			<div id="kt_activities_scroll" class="position-relative scroll-y me-n5 pe-5" data-kt-scroll="true" data-kt-scroll-height="auto" data-kt-scroll-wrappers="#kt_activities_body" data-kt-scroll-dependencies="#kt_activities_header, #kt_activities_footer" data-kt-scroll-offset="5px">
				<!--begin::Timeline items-->
				<div class="timeline">
					<!--begin::Timeline item-->
					<div class="timeline-item">
						<!--begin::Timeline line-->
						<div class="timeline-line w-40px"></div>
						<!--end::Timeline line-->
						<!--begin::Timeline icon-->
						<div class="timeline-icon symbol symbol-circle symbol-40px me-4">
							<div class="symbol-label bg-light"><?php echo getIcon('message-text-2', 'fs-2 text-gray-500'); ?></div>
						</div>
						<!--end::Timeline icon-->
						<!--begin::Timeline content-->
						<div class="timeline-content mb-10 mt-n1">
							<!--begin::Timeline heading-->
							<div class="pe-3 mb-5">
								<!--begin::Title-->
								<div class="fs-5 fw-semibold mb-2">There are 2 new tasks for you in “AirPlus Mobile App” project:</div>
								<!--end::Title-->
								<!--begin::Description-->
								<div class="d-flex align-items-center mt-1 fs-6">
									<!--begin::Info-->
									<div class="text-muted me-2 fs-7">Added at 4:23 PM by</div>
									<!--end::Info-->
									<!--begin::User-->
									<div class="symbol symbol-circle symbol-25px" data-bs-toggle="tooltip" data-bs-boundary="window" data-bs-placement="top" title="Nina Nilson">
										<img src="<?php echo e(image('avatars/300-14.jpg')); ?>" alt="img" />
									</div>
									<!--end::User-->
								</div>
								<!--end::Description-->
							</div>
							<!--end::Timeline heading-->
							<!--begin::Timeline details-->
							<div class="overflow-auto pb-5">
								<!--begin::Record-->
								<div class="d-flex align-items-center border border-dashed border-gray-300 rounded min-w-750px px-7 py-3 mb-5">
									<!--begin::Title-->
									<a href="#" class="fs-5 text-dark text-hover-primary fw-semibold w-375px min-w-200px">Meeting with customer</a>
									<!--end::Title-->
									<!--begin::Label-->
									<div class="min-w-175px pe-2">
										<span class="badge badge-light text-muted">Application Design</span>
									</div>
									<!--end::Label-->
									<!--begin::Users-->
									<div class="symbol-group symbol-hover flex-nowrap flex-grow-1 min-w-100px pe-2">
										<!--begin::User-->
										<div class="symbol symbol-circle symbol-25px">
											<img src="<?php echo e(image('avatars/300-2.jpg')); ?>" alt="img" />
										</div>
										<!--end::User-->
										<!--begin::User-->
										<div class="symbol symbol-circle symbol-25px">
											<img src="<?php echo e(image('avatars/300-14.jpg')); ?>" alt="img" />
										</div>
										<!--end::User-->
										<!--begin::User-->
										<div class="symbol symbol-circle symbol-25px">
											<div class="symbol-label fs-8 fw-semibold bg-primary text-inverse-primary">A</div>
										</div>
										<!--end::User-->
									</div>
									<!--end::Users-->
									<!--begin::Progress-->
									<div class="min-w-125px pe-2">
										<span class="badge badge-light-primary">In Progress</span>
									</div>
									<!--end::Progress-->
									<!--begin::Action-->
									<a href="#" class="btn btn-sm btn-light btn-active-light-primary">View</a>
									<!--end::Action-->
								</div>
								<!--end::Record-->
								<!--begin::Record-->
								<div class="d-flex align-items-center border border-dashed border-gray-300 rounded min-w-750px px-7 py-3 mb-0">
									<!--begin::Title-->
									<a href="#" class="fs-5 text-dark text-hover-primary fw-semibold w-375px min-w-200px">Project Delivery Preparation</a>
									<!--end::Title-->
									<!--begin::Label-->
									<div class="min-w-175px">
										<span class="badge badge-light text-muted">CRM System Development</span>
									</div>
									<!--end::Label-->
									<!--begin::Users-->
									<div class="symbol-group symbol-hover flex-nowrap flex-grow-1 min-w-100px">
										<!--begin::User-->
										<div class="symbol symbol-circle symbol-25px">
											<img src="<?php echo e(image('avatars/300-20.jpg')); ?>" alt="img" />
										</div>
										<!--end::User-->
										<!--begin::User-->
										<div class="symbol symbol-circle symbol-25px">
											<div class="symbol-label fs-8 fw-semibold bg-success text-inverse-primary">B</div>
										</div>
										<!--end::User-->
									</div>
									<!--end::Users-->
									<!--begin::Progress-->
									<div class="min-w-125px">
										<span class="badge badge-light-success">Completed</span>
									</div>
									<!--end::Progress-->
									<!--begin::Action-->
									<a href="#" class="btn btn-sm btn-light btn-active-light-primary">View</a>
									<!--end::Action-->
								</div>
								<!--end::Record-->
							</div>
							<!--end::Timeline details-->
						</div>
						<!--end::Timeline content-->
					</div>
					<!--end::Timeline item-->
					<!--begin::Timeline item-->
					<div class="timeline-item">
						<!--begin::Timeline line-->
						<div class="timeline-line w-40px"></div>
						<!--end::Timeline line-->
						<!--begin::Timeline icon-->
						<div class="timeline-icon symbol symbol-circle symbol-40px">
							<div class="symbol-label bg-light"><?php echo getIcon('flag', 'fs-2 text-gray-500'); ?></div>
						</div>
						<!--end::Timeline icon-->
						<!--begin::Timeline content-->
						<div class="timeline-content mb-10 mt-n2">
							<!--begin::Timeline heading-->
							<div class="overflow-auto pe-3">
								<!--begin::Title-->
								<div class="fs-5 fw-semibold mb-2">Invitation for crafting engaging designs that speak human workshop</div>
								<!--end::Title-->
								<!--begin::Description-->
								<div class="d-flex align-items-center mt-1 fs-6">
									<!--begin::Info-->
									<div class="text-muted me-2 fs-7">Sent at 4:23 PM by</div>
									<!--end::Info-->
									<!--begin::User-->
									<div class="symbol symbol-circle symbol-25px" data-bs-toggle="tooltip" data-bs-boundary="window" data-bs-placement="top" title="Alan Nilson">
										<img src="<?php echo e(image('avatars/300-1.jpg')); ?>" alt="img" />
									</div>
									<!--end::User-->
								</div>
								<!--end::Description-->
							</div>
							<!--end::Timeline heading-->
						</div>
						<!--end::Timeline content-->
					</div>
					<!--end::Timeline item-->
					<!--begin::Timeline item-->
					<div class="timeline-item">
						<!--begin::Timeline line-->
						<div class="timeline-line w-40px"></div>
						<!--end::Timeline line-->
						<!--begin::Timeline icon-->
						<div class="timeline-icon symbol symbol-circle symbol-40px">
							<div class="symbol-label bg-light"><?php echo getIcon('disconnect', 'fs-2 text-gray-500'); ?></div>
						</div>
						<!--end::Timeline icon-->
						<!--begin::Timeline content-->
						<div class="timeline-content mb-10 mt-n1">
							<!--begin::Timeline heading-->
							<div class="mb-5 pe-3">
								<!--begin::Title-->
								<a href="#" class="fs-5 fw-semibold text-gray-800 text-hover-primary mb-2">3 New Incoming Project Files:</a>
								<!--end::Title-->
								<!--begin::Description-->
								<div class="d-flex align-items-center mt-1 fs-6">
									<!--begin::Info-->
									<div class="text-muted me-2 fs-7">Sent at 10:30 PM by</div>
									<!--end::Info-->
									<!--begin::User-->
									<div class="symbol symbol-circle symbol-25px" data-bs-toggle="tooltip" data-bs-boundary="window" data-bs-placement="top" title="Jan Hummer">
										<img src="<?php echo e(image('avatars/300-23.jpg')); ?>" alt="img" />
									</div>
									<!--end::User-->
								</div>
								<!--end::Description-->
							</div>
							<!--end::Timeline heading-->
							<!--begin::Timeline details-->
							<div class="overflow-auto pb-5">
								<div class="d-flex align-items-center border border-dashed border-gray-300 rounded min-w-700px p-5">
									<!--begin::Item-->
									<div class="d-flex flex-aligns-center pe-10 pe-lg-20">
										<!--begin::Icon-->
										<img alt="" class="w-30px me-3" src="<?php echo e(image('svg/files/pdf.svg')); ?>" />
										<!--end::Icon-->
										<!--begin::Info-->
										<div class="ms-1 fw-semibold">
											<!--begin::Desc-->
											<a href="#" class="fs-6 text-hover-primary fw-bold">Finance KPI App Guidelines</a>
											<!--end::Desc-->
											<!--begin::Number-->
											<div class="text-gray-400">1.9mb</div>
											<!--end::Number-->
										</div>
										<!--begin::Info-->
									</div>
									<!--end::Item-->
									<!--begin::Item-->
									<div class="d-flex flex-aligns-center pe-10 pe-lg-20">
										<!--begin::Icon-->
										<img alt="?page=apps/projects/project" class="w-30px me-3" src="<?php echo e(image('svg/files/doc.svg')); ?>" />
										<!--end::Icon-->
										<!--begin::Info-->
										<div class="ms-1 fw-semibold">
											<!--begin::Desc-->
											<a href="#" class="fs-6 text-hover-primary fw-bold">Client UAT Testing Results</a>
											<!--end::Desc-->
											<!--begin::Number-->
											<div class="text-gray-400">18kb</div>
											<!--end::Number-->
										</div>
										<!--end::Info-->
									</div>
									<!--end::Item-->
									<!--begin::Item-->
									<div class="d-flex flex-aligns-center">
										<!--begin::Icon-->
										<img alt="?page=apps/projects/project" class="w-30px me-3" src="<?php echo e(image('svg/files/css.svg')); ?>" />
										<!--end::Icon-->
										<!--begin::Info-->
										<div class="ms-1 fw-semibold">
											<!--begin::Desc-->
											<a href="#" class="fs-6 text-hover-primary fw-bold">Finance Reports</a>
											<!--end::Desc-->
											<!--begin::Number-->
											<div class="text-gray-400">20mb</div>
											<!--end::Number-->
										</div>
										<!--end::Icon-->
									</div>
									<!--end::Item-->
								</div>
							</div>
							<!--end::Timeline details-->
						</div>
						<!--end::Timeline content-->
					</div>
					<!--end::Timeline item-->
					<!--begin::Timeline item-->
					<div class="timeline-item">
						<!--begin::Timeline line-->
						<div class="timeline-line w-40px"></div>
						<!--end::Timeline line-->
						<!--begin::Timeline icon-->
						<div class="timeline-icon symbol symbol-circle symbol-40px">
							<div class="symbol-label bg-light"><?php echo getIcon('abstract-26', 'fs-2 text-gray-500'); ?></div>
						</div>
						<!--end::Timeline icon-->
						<!--begin::Timeline content-->
						<div class="timeline-content mb-10 mt-n1">
							<!--begin::Timeline heading-->
							<div class="pe-3 mb-5">
								<!--begin::Title-->
								<div class="fs-5 fw-semibold mb-2">Task
								<a href="#" class="text-primary fw-bold me-1">#45890</a>merged with
								<a href="#" class="text-primary fw-bold me-1">#45890</a>in “Ads Pro Admin Dashboard project:</div>
								<!--end::Title-->
								<!--begin::Description-->
								<div class="d-flex align-items-center mt-1 fs-6">
									<!--begin::Info-->
									<div class="text-muted me-2 fs-7">Initiated at 4:23 PM by</div>
									<!--end::Info-->
									<!--begin::User-->
									<div class="symbol symbol-circle symbol-25px" data-bs-toggle="tooltip" data-bs-boundary="window" data-bs-placement="top" title="Nina Nilson">
										<img src="<?php echo e(image('avatars/300-14.jpg')); ?>" alt="img" />
									</div>
									<!--end::User-->
								</div>
								<!--end::Description-->
							</div>
							<!--end::Timeline heading-->
						</div>
						<!--end::Timeline content-->
					</div>
					<!--end::Timeline item-->
					<!--begin::Timeline item-->
					<div class="timeline-item">
						<!--begin::Timeline line-->
						<div class="timeline-line w-40px"></div>
						<!--end::Timeline line-->
						<!--begin::Timeline icon-->
						<div class="timeline-icon symbol symbol-circle symbol-40px">
							<div class="symbol-label bg-light"><?php echo getIcon('pencil', 'fs-2 text-gray-500'); ?></div>
						</div>
						<!--end::Timeline icon-->
						<!--begin::Timeline content-->
						<div class="timeline-content mb-10 mt-n1">
							<!--begin::Timeline heading-->
							<div class="pe-3 mb-5">
								<!--begin::Title-->
								<div class="fs-5 fw-semibold mb-2">3 new application design concepts added:</div>
								<!--end::Title-->
								<!--begin::Description-->
								<div class="d-flex align-items-center mt-1 fs-6">
									<!--begin::Info-->
									<div class="text-muted me-2 fs-7">Created at 4:23 PM by</div>
									<!--end::Info-->
									<!--begin::User-->
									<div class="symbol symbol-circle symbol-25px" data-bs-toggle="tooltip" data-bs-boundary="window" data-bs-placement="top" title="Marcus Dotson">
										<img src="<?php echo e(image('avatars/300-2.jpg')); ?>" alt="img" />
									</div>
									<!--end::User-->
								</div>
								<!--end::Description-->
							</div>
							<!--end::Timeline heading-->
							<!--begin::Timeline details-->
							<div class="overflow-auto pb-5">
								<div class="d-flex align-items-center border border-dashed border-gray-300 rounded min-w-700px p-7">
									<!--begin::Item-->
									<div class="overlay me-10">
										<!--begin::Image-->
										<div class="overlay-wrapper">
											<img alt="img" class="rounded w-150px" src="<?php echo e(image('stock/600x400/img-29.jpg')); ?>" />
										</div>
										<!--end::Image-->
										<!--begin::Link-->
										<div class="overlay-layer bg-dark bg-opacity-10 rounded">
											<a href="#" class="btn btn-sm btn-primary btn-shadow">Explore</a>
										</div>
										<!--end::Link-->
									</div>
									<!--end::Item-->
									<!--begin::Item-->
									<div class="overlay me-10">
										<!--begin::Image-->
										<div class="overlay-wrapper">
											<img alt="img" class="rounded w-150px" src="<?php echo e(image('stock/600x400/img-31.jpg')); ?>" />
										</div>
										<!--end::Image-->
										<!--begin::Link-->
										<div class="overlay-layer bg-dark bg-opacity-10 rounded">
											<a href="#" class="btn btn-sm btn-primary btn-shadow">Explore</a>
										</div>
										<!--end::Link-->
									</div>
									<!--end::Item-->
									<!--begin::Item-->
									<div class="overlay">
										<!--begin::Image-->
										<div class="overlay-wrapper">
											<img alt="img" class="rounded w-150px" src="<?php echo e(image('stock/600x400/img-40.jpg')); ?>" />
										</div>
										<!--end::Image-->
										<!--begin::Link-->
										<div class="overlay-layer bg-dark bg-opacity-10 rounded">
											<a href="#" class="btn btn-sm btn-primary btn-shadow">Explore</a>
										</div>
										<!--end::Link-->
									</div>
									<!--end::Item-->
								</div>
							</div>
							<!--end::Timeline details-->
						</div>
						<!--end::Timeline content-->
					</div>
					<!--end::Timeline item-->
					<!--begin::Timeline item-->
					<div class="timeline-item">
						<!--begin::Timeline line-->
						<div class="timeline-line w-40px"></div>
						<!--end::Timeline line-->
						<!--begin::Timeline icon-->
						<div class="timeline-icon symbol symbol-circle symbol-40px">
							<div class="symbol-label bg-light"><?php echo getIcon('sms', 'fs-2 text-gray-500'); ?></div>
						</div>
						<!--end::Timeline icon-->
						<!--begin::Timeline content-->
						<div class="timeline-content mb-10 mt-n1">
							<!--begin::Timeline heading-->
							<div class="pe-3 mb-5">
								<!--begin::Title-->
								<div class="fs-5 fw-semibold mb-2">New case
								<a href="#" class="text-primary fw-bold me-1">#67890</a>is assigned to you in Multi-platform Database Design project</div>
								<!--end::Title-->
								<!--begin::Description-->
								<div class="overflow-auto pb-5">
									<!--begin::Wrapper-->
									<div class="d-flex align-items-center mt-1 fs-6">
										<!--begin::Info-->
										<div class="text-muted me-2 fs-7">Added at 4:23 PM by</div>
										<!--end::Info-->
										<!--begin::User-->
										<a href="#" class="text-primary fw-bold me-1">Alice Tan</a>
										<!--end::User-->
									</div>
									<!--end::Wrapper-->
								</div>
								<!--end::Description-->
							</div>
							<!--end::Timeline heading-->
						</div>
						<!--end::Timeline content-->
					</div>
					<!--end::Timeline item-->
					<!--begin::Timeline item-->
					<div class="timeline-item">
						<!--begin::Timeline line-->
						<div class="timeline-line w-40px"></div>
						<!--end::Timeline line-->
						<!--begin::Timeline icon-->
						<div class="timeline-icon symbol symbol-circle symbol-40px">
							<div class="symbol-label bg-light"><?php echo getIcon('pencil', 'fs-2 text-gray-500'); ?></div>
						</div>
						<!--end::Timeline icon-->
						<!--begin::Timeline content-->
						<div class="timeline-content mb-10 mt-n1">
							<!--begin::Timeline heading-->
							<div class="pe-3 mb-5">
								<!--begin::Title-->
								<div class="fs-5 fw-semibold mb-2">You have received a new order:</div>
								<!--end::Title-->
								<!--begin::Description-->
								<div class="d-flex align-items-center mt-1 fs-6">
									<!--begin::Info-->
									<div class="text-muted me-2 fs-7">Placed at 5:05 AM by</div>
									<!--end::Info-->
									<!--begin::User-->
									<div class="symbol symbol-circle symbol-25px" data-bs-toggle="tooltip" data-bs-boundary="window" data-bs-placement="top" title="Robert Rich">
										<img src="<?php echo e(image('avatars/300-4.jpg')); ?>" alt="img" />
									</div>
									<!--end::User-->
								</div>
								<!--end::Description-->
							</div>
							<!--end::Timeline heading-->
							<!--begin::Timeline details-->
							<div class="overflow-auto pb-5">
								<?php echo $__env->make('partials/general/_notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
							<!--end::Timeline details-->
						</div>
						<!--end::Timeline content-->
					</div>
					<!--end::Timeline item-->
					<!--begin::Timeline item-->
					<div class="timeline-item">
						<!--begin::Timeline line-->
						<div class="timeline-line w-40px"></div>
						<!--end::Timeline line-->
						<!--begin::Timeline icon-->
						<div class="timeline-icon symbol symbol-circle symbol-40px">
							<div class="symbol-label bg-light"><?php echo getIcon('basket', 'fs-2 text-gray-500'); ?></div>
						</div>
						<!--end::Timeline icon-->
						<!--begin::Timeline content-->
						<div class="timeline-content mt-n1">
							<!--begin::Timeline heading-->
							<div class="pe-3 mb-5">
								<!--begin::Title-->
								<div class="fs-5 fw-semibold mb-2">New order
								<a href="#" class="text-primary fw-bold me-1">#67890</a>is placed for Workshow Planning & Budget Estimation</div>
								<!--end::Title-->
								<!--begin::Description-->
								<div class="d-flex align-items-center mt-1 fs-6">
									<!--begin::Info-->
									<div class="text-muted me-2 fs-7">Placed at 4:23 PM by</div>
									<!--end::Info-->
									<!--begin::User-->
									<a href="#" class="text-primary fw-bold me-1">Jimmy Bold</a>
									<!--end::User-->
								</div>
								<!--end::Description-->
							</div>
							<!--end::Timeline heading-->
						</div>
						<!--end::Timeline content-->
					</div>
					<!--end::Timeline item-->
				</div>
				<!--end::Timeline items-->
			</div>
			<!--end::Content-->
		</div>
		<!--end::Body-->
		<!--begin::Footer-->
		<div class="card-footer py-5 text-center" id="kt_activities_footer">
			<a href="#" class="btn btn-bg-body text-primary">View All Activities <?php echo getIcon('arrow-right', 'fs-3 text-primary'); ?></a>
		</div>
		<!--end::Footer-->
	</div>
</div>
<!--end::Activities drawer-->
<?php /**PATH /home/gombeirs/public_html/resources/views/partials/drawers/_activity-drawer.blade.php ENDPATH**/ ?>