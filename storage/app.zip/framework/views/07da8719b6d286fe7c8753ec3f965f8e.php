<?php if (isset($component)) { $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e = $attributes; } ?>
<?php $component = App\View\Components\DefaultLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.20/jspdf.plugin.autotable.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>







<style>




.select2.select2-container {
  width: 100% !important;
}

.select2.select2-container .select2-selection {
  border: 1px solid #ccc;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 20px;
  height: 34px;
  margin-bottom: 15px;
  outline: none !important;
  transition: all .15s ease-in-out;
}

.select2.select2-container .select2-selection .select2-selection__rendered {
  color: #333;
  line-height: 32px;
  padding-right: 33px;
}

.select2.select2-container .select2-selection .select2-selection__arrow {
  background: #f8f8f8;
  border-left: 1px solid #ccc;
  -webkit-border-radius: 0 3px 3px 0;
  -moz-border-radius: 0 3px 3px 0;
  border-radius: 0 3px 3px 0;
  height: 32px;
  width: 33px;
}

.select2.select2-container.select2-container--open .select2-selection.select2-selection--single {
  background: #f8f8f8;
}

.select2.select2-container.select2-container--open .select2-selection.select2-selection--single .select2-selection__arrow {
  -webkit-border-radius: 0 3px 0 0;
  -moz-border-radius: 0 3px 0 0;
  border-radius: 0 3px 0 0;
}

.select2.select2-container.select2-container--open .select2-selection.select2-selection--multiple {
  border: 1px solid #34495e;
}

.select2.select2-container .select2-selection--multiple {
  height: auto;
  min-height: 34px;
}

.select2.select2-container .select2-selection--multiple .select2-search--inline .select2-search__field {
  margin-top: 0;
  height: 32px;
}

.select2.select2-container .select2-selection--multiple .select2-selection__rendered {
  display: block;
  padding: 0 4px;
  line-height: 29px;
}

.select2.select2-container .select2-selection--multiple .select2-selection__choice {
  background-color: #f8f8f8;
  border: 1px solid #ccc;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 3px;
  margin: 4px 4px 0 0;
  padding: 0 6px 0 22px;
  height: 24px;
  line-height: 24px;
  font-size: 12px;
  position: relative;
}


.select2-container .select2-dropdown {
  background: transparent;
  border: none;
  margin-top: -5px;
}

.select2-container .select2-dropdown .select2-search {
  padding: 0;
}

.select2-container .select2-dropdown .select2-search input {
  outline: none !important;
  border: 1px solid #34495e !important;
  border-bottom: none !important;
  padding: 4px 6px !important;
}

.select2-container .select2-dropdown .select2-results {
  padding: 0;
}

.select2-container .select2-dropdown .select2-results ul {
  background: #fff;
  border: 1px solid #34495e;
}

.select2-container .select2-dropdown .select2-results ul .select2-results__option--highlighted[aria-selected] {
  background-color: #3498db;
}

table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

form {
	margin:auto;
	padding:30px;
	width:400px;
	height:auto;
	overflow:hidden;
	background:white;
	box-shadow: 0 0 10px 0;
	border-radius:10px;
}

form label {
	font-size:14px;
	color:darkgray;
	cursor:pointer;
}

form label,
form input {
	float:left;
	clear:both;
}

form input {
	margin:15px 0;
	padding:15px 10px;
	width:100%;
	outline:none;
	border:1px solid #bbb;
	border-radius:20px;
	display:inline-block;
	-webkit-box-sizing:border-box;
	   -moz-box-sizing:border-box;
	        box-sizing:border-box;
    -webkit-transition:0.2s ease all;
	   -moz-transition:0.2s ease all;
	    -ms-transition:0.2s ease all;
	     -o-transition:0.2s ease all;
	        transition:0.2s ease all;
}

form input[type=date]:focus,
form input[type="date"]:focus {
	border-color:cornflowerblue;
}

button[type=submit] {
	padding:15px 50px;
	width:auto;
	background:#1abc9c;
	border:none;
	color:white;
	cursor:pointer;
	display:inline-block;
	float:right;
	clear:right;
	-webkit-transition:0.2s ease all;
	   -moz-transition:0.2s ease all;
	    -ms-transition:0.2s ease all;
	     -o-transition:0.2s ease all;
	        transition:0.2s ease all;
}

input[type=submit]:hover {
	opacity:0.8;
}

input[type="submit"]:active {
	opacity:0.4;
}
 table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px; /* Adjust margin as needed */
    }

    th, td {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #f5f5f5;
    }
</style>


<!-- Filter Selection Form -->
<?php if(empty(request()->all()) || (empty(request('start_date')) && empty(request('end_date')))): ?>

<form id="filterForm" method="GET" action="<?php echo e(url('/invoices/monthReport')); ?>">
<?php $__currentLoopData = $filterOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label for="<?php echo e($option); ?>"><?php echo e(ucfirst($option)); ?>:</label>
        <?php if($option === 'created_at'): ?>
            <!-- Start Date -->
            <input type="date" name="start_date" value="<?php echo e(request('start_date')); ?>">
            <!-- End Date -->
            <input type="date" name="end_date" value="<?php echo e(request('end_date')); ?>">
        <?php else: ?>
            <select name="<?php echo e($option); ?>[]" multiple="multiple" class="js-select2-multi">
                <option value="">Select <?php echo e(ucfirst($option)); ?></option>
                <?php $__currentLoopData = $invoices->pluck($option)->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if(in_array($value, (array)request($option))): ?> selected <?php endif; ?>><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button type="submit"  id="applyFilter" class="btn btn-sm btn-light-primary">
        <i class="ki-duotone ki-cloud-download fs-3">
            <span class="path1"></span>
            <span class="path2"></span>
        </i>Apply Filter</button>

        <script>
        // Add jQuery code to enable multi-select behavior
        $(document).ready(function() {
  $(".js-select2").select2({
    closeOnSelect: false
  });
  $(".js-select2-multi").select2({
    closeOnSelect: false
  });
  
});




    </script>
</form>

<!-- Your main view -->



<?php endif; ?>

<!-- Display Report Table after filters are applied -->
<?php if(request()->filled('taxpayer_name') || request()->filled('agency_name') || request()->filled('revenue_item_name') || request()->filled('status') || (request()->filled('start_date') && request()->filled('end_date'))): ?>
    <?php if(count($invoices) > 0): ?>

     <?php
       $totalRate = 0;
    ?>
    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
        $totalRate += $invoice->rate; // Add the rate to the sum
    ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
       

        <table id="invoice">
            <thead>
                <tr>
            <th colspan="6">
                <?php if(request()->filled('start_date') && request()->filled('end_date')): ?>
                    Date Range: <?php echo e(request('start_date')); ?> to <?php echo e(request('end_date')); ?>

                <?php endif; ?>
            </th>
        </tr>
                <tr>
                    <th colspan="6">Total Amount:  ₦<?php echo e(number_format($totalRate)); ?></th>
                </tr>
                <tr>
                    <th>Taxpayer Name</th>
                    <th>Agency Name</th>
                    <th>Subhead</th>
                    <th>Amount (₦)</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($invoice->taxpayer_name); ?></td>
                <td><?php echo e($invoice->agency_name); ?></td>
                <td><?php echo e($invoice->revenue_item_name); ?></td>
                <td><?php echo e(number_format($invoice->rate, 2)); ?></td>
                <td><?php echo e($invoice->status); ?></td>
                <td><?php echo e($invoice->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
        </table>
<br/>
       <button onclick="downloadTableAsExcel('invoice', 'InvoiceReport')" class="btn btn-success">Download as Excel</button>
                <button onclick="downloadTableAsPDF('invoice', 'InvoiceReport')" class="btn btn-danger">Download as PDF</button>

    <?php else: ?>
        <p>No records found.</p>
    <?php endif; ?>
<?php endif; ?>




       



 <script>

         $(document).ready(function() {

                // Handle agency name click
                $(document).on('click', '.agency-name', function() {
                    var agencyName = $(this).data('agency');
                    fetchRevenueItems(agencyName);
                    $('#agencies-section').hide();
                    $('#revenue-items-section').show();
                });

                // Handle revenue item name click
                $(document).on('click', '.revenue-item-name', function() {
                    var revenueItemName = $(this).data('revenue-item');
                    fetchRevenueItemDetails(revenueItemName);
                    $('#revenue-items-section').hide();
                    $('#details-section').show();
                });

                // Handle back button click
                $('#back-to-agencies').click(function() {
                    $('#revenue-items-section').hide();
                    $('#agencies-section').show();
                });

                $('#back-to-revenue-items').click(function() {
                    $('#details-section').hide();
                    $('#revenue-items-section').show();
                });
            });

            

            function fetchRevenueItemDetails(revenueItemName) {
                $.ajax({
                    url: "<?php echo e(url('/invoices/getRevenueItemDetails')); ?>",
                    method: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        revenue_item_name: revenueItemName
                    },
                    success: function(response) {
                        var detailsTable = $('#details-table tbody');
                        detailsTable.empty();
                        response.forEach(function(item) {
                            detailsTable.append('<tr><td>' + item.taxpayer_name + '</td><td>₦' + number_format(item.rate) + '</td></tr>');
                        });
                    }
                });
            }

            function number_format(number) {
                return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }

            function downloadTableAsExcel(tableId, filename) {
                var table = document.getElementById(tableId);
                var wb = XLSX.utils.table_to_book(table, { sheet: "Sheet1" });
                XLSX.writeFile(wb, filename + '.xlsx');
            }

            function downloadTableAsPDF(tableId, filename) {
                var table = document.getElementById(tableId);
                window.jsPDF = window.jspdf.jsPDF;
                var doc = new jsPDF('p', 'pt', 'a4');
                doc.autoTable({
                    html: table,
                    margin: { top: 60 },
                    styles: { fontSize: 10, cellPadding: 5, overflow: 'linebreak' },
                    headStyles: { fillColor: [22, 160, 133], textColor: [255, 255, 255], fontStyle: 'bold' },
                    bodyStyles: { fillColor: [245, 245, 245], textColor: [0, 0, 0] },
                    alternateRowStyles: { fillColor: [255, 255, 255] },
                    tableLineColor: [189, 195, 199],
                    tableLineWidth: 0.1
                });
                doc.save(filename + '.pdf');
            }
        </script>





<!-- Add this script after including html2pdf -->
<script>
   function downloadPDF() {

    window.jsPDF = window.jspdf.jsPDF;
  // Create a new jsPDF object
  var doc = new jsPDF('p', 'pt', 'a4'); // 'l' for landscape, 'pt' for points, 'a4' for paper size

  // Get the table element by its id
  var table = document.getElementById('invoice');

  // Use the autoTable plugin to add the table to the PDF document
  // Your original CSS styles
const tableStyles = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: 20,
};

const cellStyles = {
    border: '1px solid #dddddd',
    textAlign: 'left',
    padding: 8,
};

const headerStyles = {
    backgroundColor: '#f2f2f2',
};

const hoverStyles = {
    backgroundColor: '#f5f5f5',
};

// Applying styles to autoTable
doc.autoTable({
    html: table, // HTML element
    margin: { top: 60 }, // Margin from the top
    styles: { fontSize: 10, ...tableStyles }, // Font size for the table and other table styles
    headStyles: headerStyles, // Background color for the table header
    bodyStyles: cellStyles, // Styles for table body cells
    alternateRowStyles: [null, hoverStyles], // Alternate row hover style
});

  // Save the PDF document with a given name
  doc.save('report.pdf');
}

function downloadSUBHEAD() {

    window.jsPDF = window.jspdf.jsPDF;
  // Create a new jsPDF object
  var doc = new jsPDF('p', 'pt', 'a4'); // 'l' for landscape, 'pt' for points, 'a4' for paper size

  // Get the table element by its id
  var table = document.getElementById('subhead');

  // Use the autoTable plugin to add the table to the PDF document
  // Your original CSS styles
const tableStyles = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: 20,
};

const cellStyles = {
    border: '1px solid #dddddd',
    textAlign: 'left',
    padding: 8,
};

const headerStyles = {
    backgroundColor: '#f2f2f2',
};

const hoverStyles = {
    backgroundColor: '#f5f5f5',
};

// Applying styles to autoTable
doc.autoTable({
    html: table, // HTML element
    margin: { top: 60 }, // Margin from the top
    styles: { fontSize: 10, ...tableStyles }, // Font size for the table and other table styles
    headStyles: headerStyles, // Background color for the table header
    bodyStyles: cellStyles, // Styles for table body cells
    alternateRowStyles: [null, hoverStyles], // Alternate row hover style
});

  // Save the PDF document with a given name
  doc.save('SubheadReport.pdf');
}

function downloadAGENCY() {

    window.jsPDF = window.jspdf.jsPDF;
  // Create a new jsPDF object
  var doc = new jsPDF('p', 'pt', 'a4'); // 'l' for landscape, 'pt' for points, 'a4' for paper size

  // Get the table element by its id
  var table = document.getElementById('agency');

  // Use the autoTable plugin to add the table to the PDF document
  // Your original CSS styles
const tableStyles = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: 20,
};

const cellStyles = {
    border: '1px solid #dddddd',
    textAlign: 'left',
    padding: 8,
};

const headerStyles = {
    backgroundColor: '#f2f2f2',
};

const hoverStyles = {
    backgroundColor: '#f5f5f5',
};

// Applying styles to autoTable
doc.autoTable({
    html: table, // HTML element
    margin: { top: 60 }, // Margin from the top
    styles: { fontSize: 10, ...tableStyles }, // Font size for the table and other table styles
    headStyles: headerStyles, // Background color for the table header
    bodyStyles: cellStyles, // Styles for table body cells
    alternateRowStyles: [null, hoverStyles], // Alternate row hover style
});

  // Save the PDF document with a given name
  doc.save('Agencyreport.pdf');
}


</script>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $attributes = $__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__attributesOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e)): ?>
<?php $component = $__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e; ?>
<?php unset($__componentOriginal1c2e2f4f77e507b499e79defc0d48b7e); ?>
<?php endif; ?>

<?php /**PATH /home/gombeirs/public_html/resources/views/invoices/BureauDue.blade.php ENDPATH**/ ?>