<!--begin::Step 4-->
<div data-kt-stepper-element="content">
	<div class="w-100">
		<?php echo $__env->make('partials/modals/new-card/_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>
<!--end::Step 4--><?php /**PATH /home/gombeirs/public_html/resources/views/partials/modals/create-app/steps/_step-4.blade.php ENDPATH**/ ?>